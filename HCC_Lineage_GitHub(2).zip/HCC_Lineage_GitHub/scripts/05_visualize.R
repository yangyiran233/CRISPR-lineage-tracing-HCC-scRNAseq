#!/usr/bin/env Rscript

suppressPackageStartupMessages({library(Seurat);library(ggplot2)})
source('scripts/common.R')
a <- parse_args(c('seurat','out'))
dir.create(a$out,recursive=TRUE,showWarnings=FALSE)
obj <- readRDS(a$seurat)
if (!'umap' %in% names(obj@reductions)) stop('Integrated object lacks UMAP')
p <- DimPlot(obj,group.by='sample_id',reduction='umap')
ggsave(file.path(a$out,'UMAP_by_sample.pdf'),p,width=9,height=7)
p <- DimPlot(obj,group.by='tissue',reduction='umap')
ggsave(file.path(a$out,'UMAP_by_tissue.pdf'),p,width=8,height=6)
p <- DimPlot(obj,group.by='target',reduction='umap')
ggsave(file.path(a$out,'UMAP_target_barcode_match.pdf'),p,width=8,height=6)
p <- DimPlot(obj,group.by='Lineage_Clone',reduction='umap',na.value='grey90')
ggsave(file.path(a$out,'UMAP_lineage_clone.pdf'),p,width=11,height=8)
DefaultAssay(obj) <- 'RNA'
markers <- list(
  epithelial=c('EPCAM','MUC1','CDH1','OCLN','KRT7','KRT8','KRT18','KRT19','KRT20'),
  mesenchymal=c('SPARC','ZEB2','COL3A1','FN1','WNT5A','TNC','DCN','COL1A1','COL5A1','COL6A1','COL6A3'),
  emt_related=c('ZEB1','ZEB2','SNAI1','SNAI2','TWIST1','PRRX1','EPCAM','VCAM1','ITGAV','ITGB3')
)
for (name in names(markers)) {
  use <- intersect(markers[[name]],rownames(obj))
  if (length(use)==0) next
  p <- FeaturePlot(obj,features=use,reduction='umap',ncol=4)
  ggsave(file.path(a$out,paste0('UMAP_',name,'.pdf')),p,width=14,height=max(6,ceiling(length(use)/4)*3))
}
write_versions(file.path(a$out,'R_sessionInfo.txt'))
