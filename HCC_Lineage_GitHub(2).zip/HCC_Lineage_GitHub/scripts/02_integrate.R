#!/usr/bin/env Rscript

suppressPackageStartupMessages({library(Seurat);library(yaml)})
source('scripts/common.R')
a <- parse_args(c('manifest','config','qc-dir','out'))
m <- load_manifest(a$manifest)
cfg <- read_yaml(a$config)$integration
set.seed(cfg$seed)
dir.create(a$out,recursive=TRUE,showWarnings=FALSE)
objects <- lapply(m$sample_id,function(id) {
  path <- file.path(a[['qc-dir']],paste0(id,'.qc.rds'))
  if (!file.exists(path)) stop('Missing QC Seurat file: ',path)
  x <- readRDS(path)
  x <- NormalizeData(x,verbose=FALSE)
  x <- FindVariableFeatures(x,selection.method='vst',nfeatures=cfg$variable_genes,verbose=FALSE)
  x
})
names(objects) <- m$sample_id
features <- SelectIntegrationFeatures(object.list=objects,nfeatures=cfg$variable_genes)
objects <- lapply(objects,function(x) {
  x <- ScaleData(x,features=features,verbose=FALSE)
  RunPCA(x,features=features,npcs=cfg$principal_components,verbose=FALSE)
})
dims <- seq_len(cfg$principal_components)
anchors <- FindIntegrationAnchors(object.list=objects,anchor.features=features,reduction='rpca',dims=dims)
combined <- IntegrateData(anchorset=anchors)
DefaultAssay(combined) <- 'integrated'
combined <- ScaleData(combined,verbose=FALSE)
combined <- RunPCA(combined,npcs=cfg$principal_components,verbose=FALSE)
combined <- RunUMAP(combined,reduction='pca',dims=dims,seed.use=cfg$seed)
combined <- FindNeighbors(combined,reduction='pca',dims=dims)
combined <- FindClusters(combined,resolution=cfg$resolution,random.seed=cfg$seed)
DefaultAssay(combined) <- 'RNA'
if (anyNA(combined$orig_barcode) || anyNA(combined$sample_id)) stop('Missing cell identity metadata after integration')
keys <- match_key(combined$sample_id,combined$orig_barcode)
if (anyDuplicated(keys)) stop('Duplicate sample/barcode IDs across integrated cells')
combined$match_key <- keys
saveRDS(combined,file.path(a$out,'integrated.rds'))
write.table(combined@meta.data,file.path(a$out,'integrated_metadata.tsv'),sep='\t',quote=FALSE,col.names=NA)
write_versions(file.path(a$out,'R_sessionInfo.txt'))
