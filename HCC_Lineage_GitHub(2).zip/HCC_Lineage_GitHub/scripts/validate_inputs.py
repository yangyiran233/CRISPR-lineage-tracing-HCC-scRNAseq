#!/usr/bin/env python3
"""Inspect supplied input paths and study metadata; fail on ambiguous sample mapping."""
import argparse
import json
import platform
import sys
from pathlib import Path
from common import load_config, load_manifest, resolve_path, sha256

def inspect(manifest_path, config_path, out, require_files=False, hashes=False):
    samples = load_manifest(manifest_path)
    config = load_config(config_path)
    if config["clone"].get("intbc_length_exact") != 14:
        raise ValueError("This release requires clone.intbc_length_exact = 14 for every group")
    required_groups = {"Huh7LT", "LC2", "LC3"}
    if not required_groups.issubset(set(samples.group)):
        raise ValueError("Expected study groups Huh7LT, LC2 and LC3 in manifest")
    if samples.duplicated(["group", "lineage_sample"]).any():
        raise ValueError("Ambiguous group and lineage_sample pairing")
    records = []
    for _, row in samples.iterrows():
        record = {k: row[k] for k in ("sample_id", "lineage_sample", "group", "tissue", "mouse_id")}
        for key in ("expression_matrix", "molecule_table", "species_assignment"):
            if key not in samples.columns or not row.get(key, ""):
                record[key + "_status"] = "not_provided"
                continue
            path = resolve_path(manifest_path, row[key])
            record[key + "_status"] = "exists" if path.exists() else "missing"
            if hashes and path.is_file():
                record[key + "_sha256"] = sha256(path)
            if require_files and not path.exists():
                raise FileNotFoundError(f"Missing {key} for {row.sample_id}: {path}")
        records.append(record)
    dest = Path(out)
    dest.mkdir(parents=True, exist_ok=True)
    report = {
        "source_manifest": str(Path(manifest_path).resolve()),
        "source_config": str(Path(config_path).resolve()),
        "config_hash": sha256(config_path),
        "python_version": sys.version,
        "platform": platform.platform(),
        "n_samples": len(samples),
        "samples": records,
        "warnings": [
            "10x-compatible delivery is not proof of original capture chemistry or barcode whitelist.",
            "Species assignment not established by a human-only count matrix.",
            "To rebuild lineage molecule tables from FASTQ, use config/preprocess.template.cfg and scripts/00_prepare_lineage_preprocess.py; preprocessing is a separate optional stage.",
            "Uniform 14-bp intBC filter is a NEW author-requested correction; rerun LC3 clones and trees before updating manuscript findings."
        ],
    }
    (dest / "input_audit.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {dest / 'input_audit.json'} ({len(samples)} samples)")
    return report

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--manifest", required=True)
    p.add_argument("--config", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--require-files", action="store_true")
    p.add_argument("--sha256", action="store_true")
    a = p.parse_args()
    inspect(a.manifest, a.config, a.out, a.require_files, a.sha256)
if __name__ == "__main__":
    main()
