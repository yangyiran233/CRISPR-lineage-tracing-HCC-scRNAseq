#!/usr/bin/env python3
"""Parameter-explicit Cassiopeia phylogeny; not a substitute for missing preprocessing.

"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from common import load_config


def summarize_character_matrix(matrix: pd.DataFrame) -> dict:
    """Missing=-1, WT=0, mutated=other; informative state shared by >=2 cells."""
    if matrix.empty:
        return {'n_cells':0, 'n_characters':0,'informative_mutated_characters':0,'observed_target_site_completeness_percent':None}
    is_observed = matrix.notna() & matrix.ne(-1)
    informative = 0
    for col in matrix.columns:
        mutated = matrix[col].loc[is_observed[col] & matrix[col].ne(0)]
        if (mutated.value_counts(dropna=True) >= 2).any():
            informative += 1
    return {
        'n_cells': int(len(matrix)),
        'n_characters': int(matrix.shape[1]),
        'informative_mutated_characters': int(informative),
        'observed_target_site_completeness_percent': round(float(is_observed.to_numpy().mean()*100), 4),
    }


def solve_allele_file(input_path: Path, output: Path, config: dict, algorithm: str | None = None):
    import cassiopeia as cas
    p = config['phylogeny']
    algorithm = algorithm or p['algorithm']
    if algorithm not in {'hybrid','greedy'}:
        raise ValueError('Algorithm must be hybrid or greedy')
    outdir = output / input_path.name.split('.tree.infile')[0]
    outdir.mkdir(parents=True, exist_ok=True)
    alleles = pd.read_csv(input_path, sep='\t', dtype={'cellBC':str, 'Sample':str})
    required = {'cellBC','intBC','r1','r2','r3','allele','lineageGrp','Sample','readCount','UMI'}
    if not required.issubset(alleles.columns):
        raise ValueError(f'Missing: {sorted(required - set(alleles.columns))}')
    # IMPORTANT: raw cellBC may be the same across samples.
    alleles['cellBC'] = alleles['Sample'] + '_' + alleles['cellBC']
    alleles = alleles.rename(columns={'lineageGrp':'LineageGroup','Sample':'sampleID'})
    alleles = alleles.dropna(subset=['r1','r2','r3','LineageGroup']).copy()
    if alleles.empty:
        raise ValueError(f'No complete r1/r2/r3 records: {input_path}')
    priors = cas.pp.compute_empirical_indel_priors(alleles, grouping_variables=['intBC','LineageGroup'])
    priors.to_csv(outdir/'indel_priors.tsv', sep='\t')
    for clone, clone_df in alleles.groupby('LineageGroup', sort=True):
        clone_path = outdir / str(clone)
        clone_path.mkdir(exist_ok=True)
        matrix, mutation_priors, state_to_indel = cas.pp.convert_alleletable_to_character_matrix(
            clone_df, allele_rep_thresh=p['allele_rep_thresh'], mutation_priors=priors)
        if matrix.empty:
            continue
        ctree = cas.data.CassiopeiaTree(character_matrix=matrix, priors=mutation_priors)
        meta = clone_df.groupby('cellBC').agg(sampleID=('sampleID','first'), n_intBC=('intBC','nunique'), umi_count=('UMI','sum'))
        ctree.cell_meta = meta
        if algorithm == 'hybrid':
            top = cas.solver.VanillaGreedySolver()
            bottom = cas.solver.ILPSolver(
                convergence_time_limit=p['ilp_time_limit_seconds'],
                maximum_potential_graph_layer_size=p['ilp_max_layer_size'],
                weighted=p['weighted'], seed=p['seed'])
            solver = cas.solver.HybridSolver(top_solver=top, bottom_solver=bottom, cell_cutoff=p['cell_cutoff'], threads=p['threads'])
        else:
            solver = cas.solver.VanillaGreedySolver()
        solver.solve(ctree, logfile=str(clone_path/f'{algorithm}.log'))
        (clone_path / f'{clone}.{algorithm}.newick').write_text(ctree.get_newick(), encoding='utf-8')
        matrix.to_csv(clone_path / f'{clone}.character_matrix.tsv', sep='\t')
        stats = summarize_character_matrix(matrix)
        stats.update(clone=clone, solver=algorithm, allele_rep_thresh=p['allele_rep_thresh'], cell_cutoff=p['cell_cutoff'] if algorithm=='hybrid' else None)
        (clone_path / 'tree_stats.json').write_text(json.dumps(stats, indent=2),encoding='utf-8')
        print(f'{clone} [{algorithm}] {stats}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--input-dir', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--algorithm', choices=['hybrid','greedy'], default=None)
    args = parser.parse_args()
    cfg = load_config(args.config)
    out = Path(args.out)
    for group in ('LC2','LC3'):
        path = Path(args.input_dir) / f'{group}.tree.infile.txt'
        if not path.exists():
            raise FileNotFoundError(path)
        solve_allele_file(path, out, cfg, args.algorithm)
if __name__ == '__main__':
    main()
