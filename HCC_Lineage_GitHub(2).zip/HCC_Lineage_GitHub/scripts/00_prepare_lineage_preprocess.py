#!/usr/bin/env python3
"""Generate and optionally execute Cassiopeia lineage preprocessing configs.

The source config documents preprocessing of provider-delivered *10x-compatible*
paired FASTQ reads. 
"""
from __future__ import annotations

import argparse
import configparser
import csv
import json
import re
import shutil
import subprocess
from pathlib import Path

REQUIRED_COLUMNS = ("fastq1", "fastq2", "sample_name")
VALID_SAMPLE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")


def _input_path(repo: Path, value: str) -> Path:
    path = Path(value).expanduser()
    return (path if path.is_absolute() else repo / path).resolve()


def read_fastq_manifest(path: Path) -> list[dict]:
    """Support a headered CSV and the historic `fastq1,fastq2,sample_name` rows."""
    with path.open(newline="", encoding="utf-8-sig") as stream:
        rows = [row for row in csv.reader(stream) if row and not row[0].lstrip().startswith("#")]
    if not rows:
        raise ValueError(f"No FASTQ records in {path}")
    if tuple(x.strip() for x in rows[0]) == REQUIRED_COLUMNS:
        rows = rows[1:]
    records = []
    seen = set()
    for idx, row in enumerate(rows, 1):
        if len(row) != 3 or not all(v.strip() for v in row):
            raise ValueError(f"Invalid FASTQ manifest row {idx}: expected fastq1,fastq2,sample_name")
        r1, r2, sample = (v.strip() for v in row)
        if not VALID_SAMPLE.fullmatch(sample):
            raise ValueError(f"Unsafe or invalid sample name {sample!r}")
        if sample in seen:
            raise ValueError(f"Duplicate sample name {sample!r}")
        seen.add(sample)
        if r1 == r2:
            raise ValueError(f"FASTQ R1 and R2 are identical for {sample}")
        records.append(dict(fastq1=r1, fastq2=r2, sample_name=sample))
    if not records:
        raise ValueError("No data rows in FASTQ manifest")
    return records


def build_config(template: Path, sample: str, fastq1: Path, fastq2: Path,
                 reference_fasta: Path, barcode_whitelist: Path, out_dir: Path, threads: int = 32):
    cfg = configparser.ConfigParser(interpolation=None)
    cfg.optionxform = str
    if not cfg.read(template, encoding="utf-8"):
        raise FileNotFoundError(template)
    for section in ('general', 'convert', 'error_correct_cellbcs_to_whitelist',
                    'call_alleles', 'filter_molecule_table', 'call_lineages'):
        if not cfg.has_section(section):
            raise ValueError(f"Missing [{section}] in template")
    if cfg.get('convert','chemistry') != '"10xv3"':
        raise ValueError("Expected original 10xv3 FASTQ interpretation in template")
    cfg['general']['name'] = json.dumps(sample)
    cfg['general']['input_files'] = json.dumps([str(fastq1), str(fastq2)])
    cfg['general']['output_directory'] = json.dumps(str(out_dir.resolve()))
    cfg['general']['reference_filepath'] = json.dumps(str(reference_fasta))
    cfg['general']['n_threads'] = str(threads)
    cfg['error_correct_cellbcs_to_whitelist']['whitelist'] = json.dumps(str(barcode_whitelist))
    return cfg


def run(args):
    repo = Path(__file__).resolve().parents[1]
    manifest = Path(args.manifest).resolve()
    template = Path(args.template).resolve()
    out_root = Path(args.out).resolve()
    reference = _input_path(repo, args.reference_fasta)
    whitelist = _input_path(repo, args.barcode_whitelist)
    records = read_fastq_manifest(manifest)
    paths = [reference, whitelist]
    if args.threads < 1:
        raise ValueError('--threads must be >= 1')
    for entry in records:
        entry['r1'] = _input_path(repo, entry['fastq1'])
        entry['r2'] = _input_path(repo, entry['fastq2'])
        paths.extend([entry['r1'], entry['r2']])
    if not args.allow_missing_files:
        missing = [str(path) for path in paths if not path.is_file()]
        if missing:
            raise FileNotFoundError('Input/reference/whitelist files missing:\n' + '\n'.join(missing))
    if args.execute and args.allow_missing_files:
        raise ValueError('--execute cannot be combined with --allow-missing-files')
    if args.execute and shutil.which('cassiopeia-preprocess') is None:
        raise RuntimeError('cassiopeia-preprocess command is not available in PATH')
    out_root.mkdir(parents=True, exist_ok=True)
    created = []
    for entry in records:
        sample = entry['sample_name']
        dest = out_root / sample
        dest.mkdir(parents=True, exist_ok=True)
        config_path = dest / 'preprocess.cfg'
        cfg = build_config(template, sample, entry['r1'], entry['r2'], reference,
                           whitelist, dest, args.threads)
        with config_path.open('w', encoding='utf-8') as handle:
            cfg.write(handle)
        print(f'Prepared {config_path}')
        created.append((sample, config_path))
    with (out_root / 'generated_configs.tsv').open('w', newline='', encoding='utf-8') as handle:
        w = csv.writer(handle, delimiter='\t')
        w.writerow(('sample_name','config_path'))
        w.writerows((name, str(path)) for name, path in created)
    if args.execute:
        for sample, config_path in created:
            log_path = config_path.parent / 'cassiopeia-preprocess.log'
            print(f'Running Cassiopeia preprocessing for {sample}; log: {log_path}', flush=True)
            with log_path.open('w', encoding='utf-8') as log:
                subprocess.run(['cassiopeia-preprocess', str(config_path)],
                               cwd=config_path.parent, stdout=log, stderr=subprocess.STDOUT, check=True)
    return created


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', required=True, help='CSV fastq1,fastq2,sample_name (header optional)')
    p.add_argument('--template', default='config/preprocess.template.cfg')
    p.add_argument('--out', default='results/preprocess')
    p.add_argument('--reference-fasta', required=True, help='LINEAGE AMPLICON reference FASTA, not GRCh38')
    p.add_argument('--barcode-whitelist', required=True, help='Actual Cassiopeia cell barcode whitelist')
    p.add_argument('--threads', type=int, default=32)
    p.add_argument('--allow-missing-files', action='store_true', help='Only for configuration preview/tests')
    p.add_argument('--execute', action='store_true', help='Run cassiopeia-preprocess after config generation')
    run(p.parse_args())


if __name__ == '__main__':
    main()
