#!/usr/bin/env Rscript
# Exact sample+barcode matching; avoids collisions of the same barcode across tissues.
suppressPackageStartupMessages({library(Seurat);library(yaml)})
source('scripts/common.R')
a <- parse_args(c('manifest','config','seurat','clone-dir','out'))
m <- load_manifest(a$manifest)
cfg <- read_yaml(a$config)
obj <- readRDS(a$seurat)
dir.create(a$out,recursive=TRUE,showWarnings=FALSE)
meta <- obj@meta.data
if (!all(c('sample_id','orig_barcode','match_key') %in% colnames(meta))) stop('Missing integrated identity metadata')
if (anyDuplicated(meta$match_key)) stop('Duplicate integrated sample+barcode keys')

# 'Target' in historical Yao.R was based on molecule-table barcode presence.
# Do not equate this with successful lineage-CLONE assignment.
target_keys <- character()
for (i in seq_len(nrow(m))) {
  path <- resolve_input(a$manifest,m$molecule_table[i])
  if (!file.exists(path)) stop('Missing filtered molecule table: ',path)
  t <- read.delim(path,stringsAsFactors=FALSE,check.names=FALSE)
  if (!'cellBC' %in% names(t)) stop('Missing cellBC in ',path)
  target_keys <- c(target_keys, match_key(m$sample_id[i],unique(t$cellBC)))
}
obj$target <- ifelse(meta$match_key %in% target_keys,'Target','Other')

all_assignments <- list()
for (group in c('LC2','LC3')) {
  file <- file.path(a[['clone-dir']],paste0(group,'.clonal_lineage.tsv'))
  if (!file.exists(file)) stop('Missing lineage clone assignment: ',file)
  tab <- read.delim(file,stringsAsFactors=FALSE,check.names=FALSE)
  tab <- tab[!is.na(tab$lineageGrp) & nzchar(tab$lineageGrp),]
  relevant <- m[m$group==group,,drop=FALSE]
  ids <- match(tab$Sample,relevant$lineage_sample)
  if (anyNA(ids)) stop('Unmatched lineage sample ID in ',group)
  tab$sample_id <- relevant$sample_id[ids]
  tab$match_key <- match_key(tab$sample_id,tab$cellBC)
  tab$Lineage_Clone <- paste(group,tab$lineageGrp,sep='_')
  all_assignments[[group]] <- tab[,c('match_key','Lineage_Clone')]
}
assign <- do.call(rbind,all_assignments)
if (anyDuplicated(assign$match_key)) stop('Conflicting lineage assignments for the same sample+barcode')
index <- match(obj$match_key,assign$match_key)
obj$Lineage_Clone <- assign$Lineage_Clone[index]
obj$metastatic_clone_type <- NA_character_
obj$metastatic_clone_type[obj$Lineage_Clone %in% cfg$exploratory_de$group_high] <- 'high'
obj$metastatic_clone_type[obj$Lineage_Clone %in% cfg$exploratory_de$group_low] <- 'low'
summary <- do.call(rbind,lapply(split(obj@meta.data,obj$sample_id),function(x)
  data.frame(sample_id=x$sample_id[1],all_cells=nrow(x),target_cells=sum(x$target=='Target'),
             lineage_matched=sum(!is.na(x$Lineage_Clone)),high=sum(x$metastatic_clone_type=='high',na.rm=TRUE),
             low=sum(x$metastatic_clone_type=='low',na.rm=TRUE))))
write.table(summary,file.path(a$out,'barcode_join_summary.tsv'),sep='\t',row.names=FALSE,quote=FALSE)
saveRDS(obj,file.path(a$out,'integrated_with_clones.rds'))
write_versions(file.path(a$out,'R_sessionInfo.txt'))
