#!/usr/bin/env Rscript
# Descriptive single-cell Wilcoxon DE with BH-FDR. 
suppressPackageStartupMessages({library(Seurat);library(yaml);library(ggplot2)})
source('scripts/common.R')
a <- parse_args(c('config','seurat','out'))
cfg <- read_yaml(a$config)$exploratory_de
obj <- readRDS(a$seurat)
set.seed(cfg$seed)
dir.create(a$out,recursive=TRUE,showWarnings=FALSE)
DefaultAssay(obj) <- 'RNA'
# Seurat 5 assays may have separately stored RNA layers after integration.
if (inherits(obj[['RNA']],'Assay5')) {
  obj <- JoinLayers(obj,assay='RNA')
}
meta <- obj@meta.data
keep <- which(meta$target=='Target' & meta$metastatic_clone_type %in% c('high','low'))
if (length(keep)<5) stop('No sufficient Target cells with high/low clone annotation')
obj <- subset(obj,cells=colnames(obj)[keep])
if (length(unique(obj$metastatic_clone_type)) != 2) stop('Both high and low groups are required')

analyze <- function(object, suffix) {
  marker <- FindMarkers(object,ident.1='high',ident.2='low',group.by='metastatic_clone_type',
    test.use='wilcox',logfc.threshold=0,only.pos=FALSE,min.pct=0.01,assay='RNA')
  marker$gene <- rownames(marker)
  marker$p_BH_FDR <- p.adjust(marker$p_val,method='BH')
  fc <- if ('avg_log2FC' %in% names(marker)) 'avg_log2FC' else if ('avg_logFC' %in% names(marker)) 'avg_logFC' else stop('Unknown fold-change column')
  marker$status <- 'NS'
  marker$status[marker$p_BH_FDR<cfg$fdr_threshold & marker[[fc]]>cfg$log2fc_threshold] <- 'Up'
  marker$status[marker$p_BH_FDR<cfg$fdr_threshold & marker[[fc]]< -cfg$log2fc_threshold] <- 'Down'
  write.table(marker,file.path(a$out,paste0(suffix,'.all_genes.tsv')),sep='\t',row.names=FALSE,quote=FALSE)
  write.table(marker[marker$status!='NS',],file.path(a$out,paste0(suffix,'.BH_significant.tsv')),sep='\t',row.names=FALSE,quote=FALSE)
  if (suffix=='all_clones') {
    marker$neglog10 <- -log10(pmax(marker$p_BH_FDR,.Machine$double.xmin))
    p <- ggplot(marker,aes(x=.data[[fc]],y=neglog10,color=status))+geom_point(alpha=.7,size=.8)+
      geom_vline(xintercept=c(-cfg$log2fc_threshold,cfg$log2fc_threshold),linetype='dashed')+
      geom_hline(yintercept=-log10(cfg$fdr_threshold),linetype='dashed')+
      labs(x='log2 fold-change (high vs low)',y='-log10(BH FDR)',title='Exploratory cell-level comparison')+
      theme_classic()
    ggsave(file.path(a$out,'volcano_BH_FDR.pdf'),p,width=7,height=5)
  }
  data.frame(analysis=suffix,n_cells=ncol(object),n_high=sum(object$metastatic_clone_type=='high'),
             n_low=sum(object$metastatic_clone_type=='low'),n_up=sum(marker$status=='Up'),n_down=sum(marker$status=='Down'))
}
results <- list(analyze(obj,'all_clones'))
# NEW: leave-one-clone-out sensitivity; still not independent replicate testing.
for (clone in sort(unique(obj$Lineage_Clone))) {
  subset_obj <- subset(obj,cells=colnames(obj)[obj$Lineage_Clone != clone])
  if (length(unique(subset_obj$metastatic_clone_type))!=2) next
  results[[length(results)+1]] <- analyze(subset_obj,paste0('exclude_',clone))
}
write.table(do.call(rbind,results),file.path(a$out,'sensitivity_summary.tsv'),sep='\t',row.names=FALSE,quote=FALSE)
write_versions(file.path(a$out,'R_sessionInfo.txt'))
