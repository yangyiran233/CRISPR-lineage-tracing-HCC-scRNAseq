# Shared manifest and argument helpers. All paths are resolved relative to repository.
parse_args <- function(required, optional = character()) {
  x <- commandArgs(trailingOnly = TRUE)
  if (length(x) %% 2 != 0) stop('Arguments must be --name value pairs')
  if (length(x) && any(!startsWith(x[seq(1, length(x), 2)], '--'))) stop('Expected --name value')
  keys <- sub('^--', '', x[seq(1, length(x), 2)])
  values <- x[seq(2, length(x), 2)]
  result <- as.list(setNames(values, keys))
  missing <- setdiff(required, names(result))
  if (length(missing)) stop('Missing arguments: ', paste(missing, collapse=', '))
  result
}
load_manifest <- function(file) {
  x <- read.delim(file, sep='\t', check.names=FALSE, stringsAsFactors=FALSE, na.strings=NULL)
  needed <- c('sample_id','lineage_sample','group','tissue','mouse_id','expression_matrix','molecule_table')
  if (!all(needed %in% names(x))) stop('Manifest missing: ', paste(setdiff(needed,names(x)),collapse=', '))
  if (anyDuplicated(x$sample_id) || anyDuplicated(x$lineage_sample)) stop('Sample IDs must be unique')
  x
}
resolve_input <- function(manifest, value) {
  if (is.na(value) || !nzchar(value)) return('')
  if (startsWith(value, '/') || grepl('^[A-Za-z]:[/\\\\]', value)) return(path.expand(value))
  file.path(dirname(dirname(normalizePath(manifest))), value)
}
normalize_barcode <- function(x) sub('-[0-9]+$', '', as.character(x))
match_key <- function(sample_id, bc) paste0(sample_id, '|', normalize_barcode(bc))
write_versions <- function(output) {
  sink(output)
  print(sessionInfo())
  sink()
}
read_yaml <- function(file) yaml::read_yaml(file)
