"""Shared helpers for manifest-driven lineage analyses; no site-specific paths."""
from __future__ import annotations
import hashlib
from pathlib import Path
import pandas as pd
import yaml

REQUIRED = ("sample_id", "lineage_sample", "group", "tissue", "mouse_id", "expression_matrix", "molecule_table")

def load_config(path: str | Path) -> dict:
    with open(path, encoding="utf-8") as handle:
        return yaml.safe_load(handle)

def load_manifest(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path, sep="\t", dtype=str, keep_default_na=False)
    missing = set(REQUIRED) - set(df.columns)
    if missing:
        raise ValueError(f"Manifest is missing columns: {sorted(missing)}")
    if df.empty:
        raise ValueError("Manifest is empty")
    for col in ("sample_id", "lineage_sample"):
        if not df[col].is_unique or any(not value.strip() for value in df[col]):
            raise ValueError(f"{col} must contain nonempty unique values")
    return df

def resolve_path(manifest_path: str | Path, value: str) -> Path:
    root = Path(manifest_path).resolve().parent.parent
    p = Path(value).expanduser()
    return p if p.is_absolute() else root / p

def sha256(path: str | Path) -> str:
    hasher = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()

def clean_barcode(value: str) -> str:
    """Remove only a trailing 10x gem-group suffix, not internal hyphens."""
    import re
    return re.sub(r"-\d+$", "", str(value))

def match_key(sample_id: str, barcode: str) -> str:
    return f"{sample_id}|{clean_barcode(barcode)}"
