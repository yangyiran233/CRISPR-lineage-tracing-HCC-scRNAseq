#!/usr/bin/env Rscript
# Per-sample 10x-compatible count-matrix QC. CellRanger is NOT run by this script.
suppressPackageStartupMessages({library(Seurat);library(yaml);library(DoubletFinder)})
source('scripts/common.R')
a <- parse_args(c('manifest','config','out'))
m <- load_manifest(a$manifest)
conf <- read_yaml(a$config)$qc
set.seed(1234) # newly explicit, not documented in historical scripts
out <- a$out
dir.create(out,recursive=TRUE,showWarnings=FALSE)

call_df <- function(seu, p, frac, n_pcs) {
  # The historical script used paramSweep_v3 and doubletFinder_v3; names differ by version.
  pick <- function(old,new) {
    names <- getNamespaceExports('DoubletFinder')
    if (new %in% names) return(getExportedValue('DoubletFinder',new))
    if (old %in% names) return(getExportedValue('DoubletFinder',old))
    stop('DoubletFinder function missing: ',new,' / ',old,'; record/install a compatible version')
  }
  do_sweep <- pick('paramSweep_v3','paramSweep')
  find_doublets <- pick('doubletFinder_v3','doubletFinder')
  seu <- NormalizeData(seu, verbose=FALSE)
  seu <- FindVariableFeatures(seu,selection.method='vst',nfeatures=2000,verbose=FALSE)
  seu <- ScaleData(seu,verbose=FALSE)
  seu <- RunPCA(seu,npcs=n_pcs,verbose=FALSE)
  sweep <- do_sweep(seu, PCs=seq_len(n_pcs), sct=FALSE)
  stats <- DoubletFinder::summarizeSweep(sweep, GT=FALSE)
  pk <- DoubletFinder::find.pK(stats)
  metric <- if ('BCmetric' %in% names(pk)) 'BCmetric' else if ('MeanBC' %in% names(pk)) 'MeanBC' else stop('Unknown DoubletFinder pK metric')
  selected <- pk$pK[which.max(pk[[metric]])]
  selected <- as.numeric(as.character(selected))
  n_exp <- round(frac * ncol(seu))
  seu <- find_doublets(seu, PCs=seq_len(n_pcs),pN=p,pK=selected,nExp=n_exp,sct=FALSE)
  col <- tail(grep('^DF.classifications',colnames(seu@meta.data),value=TRUE),1)
  if (!length(col)) stop('DoubletFinder did not produce classification')
  seu$doublet_status <- as.character(seu@meta.data[[col]])
  attr(seu,'doublet_pK_selected') <- selected
  seu
}

qc_rows <- list()
for (i in seq_len(nrow(m))) {
  sample <- m[i,,drop=FALSE]
  sid <- sample$sample_id
  dirpath <- resolve_input(a$manifest,sample$expression_matrix)
  if (!dir.exists(dirpath)) stop('10x matrix directory is missing: ',dirpath)
  counts <- Seurat::Read10X(dirpath)
  if (is.list(counts)) {
    if (!'Gene Expression' %in% names(counts)) stop('10x matrix lacks Gene Expression assay: ',sid)
    counts <- counts[['Gene Expression']]
  }
  seu <- CreateSeuratObject(counts, project=sid,min.cells=conf$min_cells_per_gene)
  seu$sample_id <- sid
  seu$group <- sample$group
  seu$mouse_id <- sample$mouse_id
  seu$tissue <- sample$tissue
  seu$orig_barcode <- colnames(seu)
  seu[['percent.mt']] <- PercentageFeatureSet(seu, pattern='^MT-')
  pre <- ncol(seu)
  outlier <- boxplot.stats(seu$nFeature_RNA)$out
  outlier <- outlier[outlier > median(seu$nFeature_RNA)]
  upper <- if (length(outlier)) min(outlier) else Inf
  selected <- seu$nFeature_RNA > conf$min_genes_exclusive &
    seu$nFeature_RNA < upper &
    seu$nCount_RNA > conf$min_umis_exclusive &
    seu$percent.mt < conf$max_mito_percent_exclusive
  seu <- subset(seu, cells=colnames(seu)[selected])
  after_qc <- ncol(seu)
  if (after_qc < 20) stop('Too few QC-passing cells in ',sid,' (',after_qc,')')
  status <- 'not_assessed'
  # Optional NEW species assignment; cannot be inferred from a human-only matrix.
  if (identical(conf$species_mode,'external_species_table')) {
    if (!'species_assignment' %in% names(sample) || !nzchar(sample$species_assignment)) stop('External species-assignment file is required for ',sid)
    f <- resolve_input(a$manifest,sample$species_assignment)
    t <- read.delim(f,stringsAsFactors=FALSE,check.names=FALSE)
    if (!all(c('barcode','species') %in% names(t))) stop('Species TSV must have barcode and species columns')
    if (anyDuplicated(normalize_barcode(t$barcode))) stop('Duplicated species barcodes in ',sid)
    idx <- match(normalize_barcode(seu$orig_barcode),normalize_barcode(t$barcode))
    if (anyNA(idx)) stop('Species assignment missing for ',sum(is.na(idx)),' cells in ',sid)
    seu$species_assignment <- tolower(t$species[idx])
    if (!all(seu$species_assignment %in% c('human','mouse','ambiguous'))) stop('Unknown species label')
    seu <- subset(seu,subset=species_assignment=='human')
    status <- 'external_species_table'
  } else if (!identical(conf$species_mode,'not_assessed')) stop('Unsupported qc.species_mode: ',conf$species_mode)
  after_species <- ncol(seu)
  selected_pk <- NA_real_
  if (isTRUE(conf$doublet_enabled)) {
    # The original run supplied default --percentage=0.05 and did not pass a scrublet table.
    n_pcs <- min(50L,ncol(seu)-1L,nrow(seu)-1L)
    if (n_pcs < 5) stop('Not enough cells/features for DoubletFinder: ',sid)
    seu <- call_df(seu, conf$doublet_pN, conf$doublet_expected_fraction, n_pcs)
    selected_pk <- attr(seu,'doublet_pK_selected')
    seu <- subset(seu,subset=doublet_status=='Singlet')
  } else {
    seu$doublet_status <- 'not_assessed'
  }
  saved <- file.path(out,paste0(sid,'.qc.rds'))
  saveRDS(seu,saved)
  qc_rows[[length(qc_rows)+1]] <- data.frame(
    sample_id=sid, raw_after_gene_filter=pre, after_thresholds=after_qc,
    after_species=after_species, final_singlets=ncol(seu),
    retained_fraction_vs_gene_filtered=ncol(seu)/pre,
    genes_min_exclusive=conf$min_genes_exclusive,umis_min_exclusive=conf$min_umis_exclusive,
    mito_max_exclusive=conf$max_mito_percent_exclusive,
    upper_gene_outlier_cutoff=upper,doublet_expected_fraction=conf$doublet_expected_fraction,
    doublet_pK=selected_pk, species_status=status,
    doublet_enabled=isTRUE(conf$doublet_enabled))
  message(sid,': ',pre,' -> ',ncol(seu),' cells')
}
write.table(do.call(rbind,qc_rows),file.path(out,'qc_summary.tsv'),sep='\t',row.names=FALSE,quote=FALSE)
write_versions(file.path(out,'R_sessionInfo.txt'))
