#!/usr/bin/env python3
"""Manifest-based port of supplied Huh7LT/LC2/LC3 intBC clone grouping.
Cassiopeia-compatible molecule tables delivered/generated upstream.
"""
from __future__ import annotations
import argparse
import json
import sys
from collections import Counter
from pathlib import Path
import pandas as pd
from common import load_config, load_manifest, resolve_path

REQUIRED_COLS = ['cellBC', 'intBC', 'r1', 'r2', 'r3', 'allele', 'readCount', 'UMI']


def filter_molecules(df: pd.DataFrame, group: str, cfg: dict) -> tuple[pd.DataFrame, dict]:
    criteria = cfg['clone']
    s = df['allele'].astype('string')
    has_edit = s.str.contains(r'\[(?!None\])', na=False) if criteria['require_non_wt_indel'] else pd.Series(True, index=df.index)
    has_sites = s.str.count(r'\[').fillna(0) >= criteria['min_allele_brackets']
    lens = df['intBC'].astype('string').str.len()
    exact_length = criteria['intbc_length_exact']
    if not isinstance(exact_length, int) or exact_length < 1:
        raise ValueError(f'clone.intbc_length_exact must be a positive integer, got {exact_length!r}')
    passes_length = lens == exact_length
    keep = (has_edit & has_sites & passes_length).fillna(False)
    filtered = df.loc[keep].copy()
    pre_length = (has_edit & has_sites).fillna(False)
    length_distribution = lens.loc[pre_length].dropna().astype(int).value_counts().sort_index()
    return filtered, {
        'input_rows': len(df), 'filtered_rows': len(filtered),
        'removed_rows': int((~keep).sum()),
        'intbc_length_rule': {'exact': exact_length},
        'intbc_length_distribution_before_length_filter': {str(k): int(v) for k, v in length_distribution.items()},
        'rows_removed_by_length_after_edit_filters': int((pre_length & ~passes_length.fillna(False)).sum()),
    }


def infer_assignments(molecules: pd.DataFrame, cfg: dict) -> tuple[pd.DataFrame, dict]:
    """Core historical iterative clustering: rows represent unique molecule observations."""
    q = cfg['clone']
    df = molecules.copy()
    df['unique_cellBC'] = df['Sample'].astype(str) + '_' + df['cellBC'].astype(str)
    if df.empty:
        return df.assign(lineageGrp=pd.Series(dtype='object')), {'clones': {}, 'n_cells': 0}
    df['assigned'] = False
    groups = {}
    while True:
        unassigned = df.loc[~df['assigned']]
        if unassigned.empty:
            break
        counts = Counter(unassigned['intBC'])
        # stable lexical tie-breaking (historical Counter ties relied on input order)
        top_intbc = min(counts, key=lambda k: (-counts[k], str(k)))
        cells_with_top = set(unassigned.loc[unassigned['intBC'] == top_intbc, 'unique_cellBC'])
        relevant = unassigned.loc[unassigned['unique_cellBC'].isin(cells_with_top)]
        frequencies = relevant.groupby('intBC')['unique_cellBC'].nunique() / len(cells_with_top)
        intbc_set = sorted(frequencies[frequencies > q['intbc_set_cell_frequency_exclusive']].index)
        if not intbc_set:
            break
        cluster_cells = []
        for cell, subset in relevant.groupby('unique_cellBC', sort=True):
            if subset['intBC'].isin(intbc_set).mean() > q['initial_assignment_fraction_exclusive']:
                cluster_cells.append(cell)
        if not cluster_cells:
            break
        groups[f'Clone_{len(groups)+1}'] = {'intBC_set': intbc_set, 'initial_cells': len(cluster_cells)}
        df.loc[df['unique_cellBC'].isin(cluster_cells), 'assigned'] = True
        if df['assigned'].mean() > q['stop_assigned_row_fraction_exclusive']:
            break
    assignments = {}
    for cell, subset in df.groupby('unique_cellBC', sort=True):
        assignments[cell] = None
        for clone, info in groups.items():
            if subset['intBC'].isin(info['intBC_set']).mean() >= q['final_assignment_fraction_inclusive']:
                assignments[cell] = clone
                break
    df['lineageGrp'] = df['unique_cellBC'].map(assignments)
    counts = df.loc[df['lineageGrp'].notna()].groupby('lineageGrp')['unique_cellBC'].nunique()
    valid = set(counts[counts >= q['min_clone_cells']].index)
    df = df.loc[df['lineageGrp'].isin(valid)].copy()
    return df, {'clones': groups, 'n_cells': len(assignments), 'retained_clones': sorted(valid), 'retained_cells': df['unique_cellBC'].nunique()}


def collapse_alleles(df: pd.DataFrame, conflict_mode='first') -> tuple[pd.DataFrame, pd.DataFrame]:
    keys = ['cellBC', 'intBC', 'Sample']
    raw = df[REQUIRED_COLS + ['Sample', 'lineageGrp']].copy()
    raw['readCount'] = pd.to_numeric(raw['readCount'], errors='raise')
    conflicts = raw.groupby(keys, dropna=False)['allele'].nunique().reset_index(name='n_alleles')
    conflicts = conflicts.loc[conflicts.n_alleles > 1]
    # Historical code used first allele and aggregated read counts, without voting.
    if conflict_mode == 'majority':
        scores = raw.groupby(keys + ['allele'], dropna=False)['readCount'].sum().reset_index(name='allele_reads')
        winners = scores.sort_values(keys + ['allele_reads', 'allele'], ascending=[True, True, True, False, True]).drop_duplicates(keys)
        representative = raw.merge(winners[keys + ['allele']], on=keys + ['allele'], how='inner').drop_duplicates(keys)
    elif conflict_mode == 'first':
        representative = raw.drop_duplicates(keys)
    else:
        raise ValueError('conflicting_alleles must be first or majority')
    summary = raw.groupby(keys, dropna=False).agg(readCount=('readCount', 'sum'), UMI=('UMI', 'nunique')).reset_index()
    representative = representative[keys + ['r1', 'r2', 'r3', 'allele', 'lineageGrp']]
    collapsed = representative.merge(summary, on=keys, how='inner', validate='one_to_one')
    return collapsed[['cellBC','intBC','r1','r2','r3','allele','lineageGrp','Sample','readCount','UMI']], conflicts


def run(manifest_path: str, config_path: str, output_dir: str) -> None:
    config = load_config(config_path)
    manifest = load_manifest(manifest_path)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    for group in ['Huh7LT', 'LC2', 'LC3']:
        cohort = manifest.loc[manifest.group == group]
        if cohort.empty:
            raise ValueError(f'No samples for group: {group}')
        frames = []
        for _, sample in cohort.iterrows():
            path = resolve_path(manifest_path, sample.molecule_table)
            raw = pd.read_csv(path, sep='\t', dtype={'cellBC':'string', 'intBC':'string','UMI':'string'})
            missing = set(REQUIRED_COLS) - set(raw.columns)
            if missing:
                raise ValueError(f'{sample.sample_id} missing required molecule columns: {sorted(missing)}')
            raw['Sample'] = sample.lineage_sample
            frames.append(raw)
        pooled = pd.concat(frames, ignore_index=True)
        filtered, filter_stats = filter_molecules(pooled, group, config)
        labeled, clone_stats = infer_assignments(filtered, config)
        labeled.to_csv(output / f'{group}.labeled_molecules.tsv.gz', sep='\t', index=False, compression='gzip')
        assignments = labeled[['Sample','cellBC','lineageGrp']].drop_duplicates()
        assignments.to_csv(output / f'{group}.clonal_lineage.tsv', sep='\t', index=False)
        if labeled.empty:
            raise ValueError(f'No cells passed clone assignment for {group}; inspect thresholds and inputs')
        collapsed, conflicts = collapse_alleles(labeled, config['clone']['conflicting_alleles'])
        collapsed.to_csv(output / f'{group}.tree.infile.txt', sep='\t', index=False)
        conflicts.to_csv(output / f'{group}.allele_conflicts.tsv', sep='\t', index=False)
        report = dict(filter_stats, **clone_stats, conflicting_alleles=config['clone']['conflicting_alleles'], conflicting_groups=len(conflicts))
        (output / f'{group}.summary.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
        print(f'{group}: {clone_stats["retained_cells"]} cells; {len(clone_stats["retained_clones"])} clones; {len(conflicts)} conflicting alleles')

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--manifest', required=True)
    p.add_argument('--config', required=True)
    p.add_argument('--out', required=True)
    args = p.parse_args()
    run(args.manifest, args.config, args.out)
