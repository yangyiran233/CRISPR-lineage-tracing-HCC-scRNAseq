# Huh7-LT / LC2 / LC3 scRNA-seq and lineage-tracing


## Repository files

| Location | Purpose |
|---|---|
| `scripts/00_prepare_lineage_preprocess.py` | Validate paired FASTQ manifest, generate per-sample Cassiopeia configs, optionally run `cassiopeia-preprocess` |
| `config/preprocess.template.cfg` | Original lineage-processing parameters with local paths redacted |
| `config/lineage_fastq.example.csv` | Example paired FASTQ manifest |
| `scripts/01_scRNA_qc.R` | Per-sample expression QC and DoubletFinder; reports retention and selected pK |
| `scripts/02_integrate.R` | Seurat RPCA integration, 50-PC UMAP and clustering |
| `scripts/01_clone_assignment.py` | 14-bp intBC filter, clone assignment and audit summaries |
| `scripts/02_cassiopeia_trees.py` | Hybrid lineage trees and character completeness; alternative Greedy sensitivity analysis |
| `scripts/03_join_lineage.R` | Match lineage and expression barcodes strictly within each sample |
| `scripts/04_exploratory_de.R` | Exploratory cell-level Wilcoxon |
| `scripts/05_visualize.R` | Main exploratory plots |
| `scripts/validate_inputs.py` | Verify manifest, input paths and config checksum |
| `config/analysis.yaml` | Recovered filtering/analysis settings plus labelled new decisions |

## Installation

```bash
conda env create -f environment.yml
conda activate hcc-lineage-reproduction
# Install the compatible DoubletFinder version for your R/Seurat release.
python -m pytest -q
```

The conda file is a proposed environment, **not** an export of the historical study environment. Cassiopeia Hybrid ILP reconstruction may require additional solver/licensing configuration. 

## A. Rebuild targeted-lineage molecule tables from delivered FASTQs (optional)

The new preprocessing step is based on the provided historical `get_preprocess.py` and `preprocess.cfg`. It requires the 10x-compatible paired lineage FASTQs, the **lineage amplicon** FASTA and the actual 3M-Feb-2018 cell-barcode whitelist.

```bash
cp config/lineage_fastq.example.csv config/lineage_fastq.csv
# Edit the local manifest to point to the 6 real paired FASTQ files.
# Copy the actual reference and whitelist into data/reference/ or set full paths.
make preprocess-configs \
  FASTQ_MANIFEST=config/lineage_fastq.csv \
  LINEAGE_REFERENCE=data/reference/lineage_amplicon.fasta \
  BARCODE_WHITELIST=data/reference/3M-february-2018.txt

# Only after checking generated results/preprocess/*/preprocess.cfg:
make preprocess \
  FASTQ_MANIFEST=config/lineage_fastq.csv \
  LINEAGE_REFERENCE=data/reference/lineage_amplicon.fasta \
  BARCODE_WHITELIST=data/reference/3M-february-2018.txt
```

`make preprocess` invokes `cassiopeia-preprocess` for every sample and preserves per-sample logs. Upstream config values include `quality_threshold=10`, `max_hq_mismatches=3`, `max_indels=2`, `min_umi_per_cell=10`, `min_avg_reads_per_umi=2.0`, `barcode_interval=(20,34)` (14 bp), and cut sites `[106,161,214]`. See the template for remaining parameters. **Outputs and table filenames may vary with Cassiopeia version**; inspect the generated files and set each `molecule_table` path in the next manifest to the actual filtered molecule table. 

If the original preprocessed molecule tables are already available, skip this optional upstream step and use them directly.

## B. Expression, clone, tree and differential-expression analysis

```bash
cp config/samples.example.tsv config/samples.tsv
# Point the six rows to the real GRCh38 expression matrices and lineage molecule tables.
make test
make validate
make qc
make integrate
make clones
make trees
make join
make de
Rscript scripts/05_visualize.R --seurat results/join/integrated_with_clones.rds --out results/plots
```

Run `python scripts/02_cassiopeia_trees.py --config config/analysis.yaml --input-dir results/clones --out results/trees_greedy --algorithm greedy` only as an **explicit alternative** if the original Hybrid solver cannot run.


