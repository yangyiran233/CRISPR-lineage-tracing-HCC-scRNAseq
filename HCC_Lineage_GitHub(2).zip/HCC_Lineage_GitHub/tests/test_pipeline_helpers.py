import sys
from pathlib import Path
import importlib.util
import pandas as pd
import pytest

REPO = Path(__file__).parents[1]
sys.path.insert(0, str(REPO / 'scripts'))
from common import clean_barcode, match_key, load_manifest, load_config

def load_module(filename, name):
    spec = importlib.util.spec_from_file_location(name, REPO / 'scripts' / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

clones = load_module('01_clone_assignment.py', 'clones')
trees = load_module('02_cassiopeia_trees.py', 'trees')


def test_barcodes_preserve_hyphens_but_remove_gem_group():
    assert clean_barcode('AAACCC-1') == 'AAACCC'
    assert clean_barcode('AAACCC-2') == 'AAACCC'
    assert clean_barcode('AAACCC-extra') == 'AAACCC-extra'
    assert match_key('NGS-LC-2-insitu','ACGT-1') != match_key('NGS-LC-3-insitu','ACGT-1')


def test_manifest_six_samples_unique():
    df=load_manifest(REPO / 'config' / 'samples.example.tsv')
    assert len(df)==6
    assert set(df.group)=={'LC2','LC3','Huh7LT'}
    assert df.lineage_sample.is_unique


def test_intbc_length_unified_to_14bp_all_groups():
    cfg=load_config(REPO / 'config' / 'analysis.yaml')
    assert cfg['clone']['intbc_length_exact'] == 14
    df = pd.DataFrame({
        'allele': ['[A][None][None]'] * 4,
        'intBC': ['A'*14, 'B'*4, 'C'*15, 'D'*13],
    })
    for group in ('Huh7LT', 'LC2', 'LC3'):
        filtered, summary = clones.filter_molecules(df, group, cfg)
        assert len(filtered) == 1
        assert filtered['intBC'].iloc[0] == 'A' * 14
        assert summary['intbc_length_rule'] == {'exact': 14}
        assert summary['rows_removed_by_length_after_edit_filters'] == 3


def test_clone_grouping_uses_minimum_cells_and_umi_count():
    cfg=load_config(REPO / 'config' / 'analysis.yaml')
    n=26
    df=pd.DataFrame({
        'Sample':['NGS_LC_2_insitu']*n,
        'cellBC':[f'C{i:03d}' for i in range(n)],
        'intBC':['A'*14]*n,
        'allele':['[a][None][None]']*n,
        'r1':['a']*n,'r2':['None']*n,'r3':['None']*n,
        'readCount':[2]*n,'UMI':[f'U{i:03d}' for i in range(n)],
    })
    filtered, counts=clones.filter_molecules(df,'LC2',cfg)
    assignment, stats=clones.infer_assignments(filtered,cfg)
    assert len(assignment)==n
    assert stats['retained_clones']==['Clone_1']
    collapsed, conflicts=clones.collapse_alleles(assignment)
    assert len(collapsed)==n
    assert not len(conflicts)
    assert (collapsed.UMI==1).all()


def test_allele_conflict_first_and_majority_are_distinct():
    base = {'cellBC':'X','intBC':'A'*14,'Sample':'S','lineageGrp':'Clone_1','UMI':'u'}
    d=pd.DataFrame([dict(base,r1='a',r2='None',r3='None',allele='A',readCount=1),
                    dict(base,r1='b',r2='None',r3='None',allele='B',readCount=5,UMI='v')])
    first, conflicts=clones.collapse_alleles(d,'first')
    major, _=clones.collapse_alleles(d,'majority')
    assert first.allele.iloc[0]=='A' and major.allele.iloc[0]=='B'
    assert first.UMI.iloc[0]==2 and first.readCount.iloc[0]==6
    assert len(conflicts)==1


def test_tree_mutated_characters_and_completeness():
    matrix=pd.DataFrame({'a':[0,1,1,-1], 'b':[2,3,0,-1], 'c':[-1,-1,-1,-1]})
    d=trees.summarize_character_matrix(matrix)
    assert d['n_cells']==4
    assert d['informative_mutated_characters']==1
    assert d['observed_target_site_completeness_percent']==pytest.approx(50.0,abs=1e-4)


def test_lineage_preprocess_config_from_vendor_10x_fastqs(tmp_path):
    pre = load_module('00_prepare_lineage_preprocess.py', 'prepare_lineage')
    for filename in ('r1.fastq.gz','r2.fastq.gz','lineage.fasta','3m.txt'):
        (tmp_path / filename).write_text('test')
    cfg = pre.build_config(
        REPO / 'config' / 'preprocess.template.cfg',
        'NGS-LC-3-insitu', tmp_path / 'r1.fastq.gz', tmp_path / 'r2.fastq.gz',
        tmp_path / 'lineage.fasta', tmp_path / '3m.txt', tmp_path / 'out', threads=8,
    )
    assert cfg['convert']['chemistry'] == '"10xv3"'
    assert cfg['general']['n_threads'] == '8'
    assert cfg['call_alleles']['barcode_interval'] == '(20, 34)'
    assert cfg['filter_bam']['quality_threshold'] == '10'
    assert cfg['collapse']['max_hq_mismatches'] == '3'
    assert cfg['general']['reference_filepath'] == '"' + str(tmp_path / 'lineage.fasta') + '"'
    assert cfg['error_correct_cellbcs_to_whitelist']['whitelist'] == '"' + str(tmp_path / '3m.txt') + '"'


def test_preprocess_manifest_accepts_historical_three_column_csv(tmp_path):
    pre = load_module('00_prepare_lineage_preprocess.py', 'prepare_lineage_v2')
    f = tmp_path / 'fastqs.csv'
    f.write_text('R1.fastq.gz,R2.fastq.gz,NGS-LC-3-insitu\n')
    assert pre.read_fastq_manifest(f)[0]['sample_name'] == 'NGS-LC-3-insitu'
    f.write_text('fastq1,fastq2,sample_name\nR1.fastq.gz,R2.fastq.gz,NGS-LC-3-insitu\n')
    assert len(pre.read_fastq_manifest(f)) == 1
    f.write_text('R1.fastq.gz,R2.fastq.gz,../badname\n')
    with pytest.raises(ValueError):
        pre.read_fastq_manifest(f)
